/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package authenticationsvr.business;

import java.io.*;
import java.net.*;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amorette
 */
public class SocketMgrTest {

    @Test
    public void testSocketMgrFail() throws Exception {
        InetAddress address = InetAddress.getLocalHost();
        Socket socket = new Socket(address, 8000);
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        oos.writeObject("hellooooo/world");
        boolean isValid = (Boolean) ois.readObject();
        assertFalse(isValid);
    }
    
    public void testSocketMgrPass() throws Exception {
        InetAddress address = InetAddress.getLocalHost();
        Socket socket = new Socket(address, 8000);
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        oos.writeObject("hello/world");
        boolean isValid = (Boolean) ois.readObject();
        assertTrue(isValid);
    }

}
