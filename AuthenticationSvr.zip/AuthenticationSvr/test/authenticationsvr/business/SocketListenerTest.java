/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package authenticationsvr.business;

import org.junit.Test;
import static org.junit.Assert.*;
import java.net.*;
import java.io.*;

/**
 *
 * @author Amorette
 */
public class SocketListenerTest {

    @Test
    public void testFailAuthServer() throws Exception{
        InetAddress address = InetAddress.getLocalHost();
        Socket socket = new Socket(address, 8000);
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        oos.writeObject("hellooooo/world");
        boolean isValid = (Boolean) ois.readObject();
        assertFalse(isValid);
        socket.close();
    }

    @Test
    public void testPassAuthServer() throws Exception{
        InetAddress address = InetAddress.getLocalHost();
        Socket socket = new Socket(address, 8000);
        ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
        ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
        oos.writeObject("hello/world");
        boolean isValid = (Boolean) ois.readObject();
        assertTrue(isValid);
        socket.close();
    }
}
