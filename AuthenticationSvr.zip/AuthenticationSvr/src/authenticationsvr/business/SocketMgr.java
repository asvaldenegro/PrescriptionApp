/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package authenticationsvr.business;
import java.net.*;
import java.io.*;
/**
 *
 * @author Amorette
 */
public class SocketMgr implements Runnable {
    private Socket socket = null;
    
    public SocketMgr(Socket socket){
        this.socket = socket;
    }
    
    public void run() {
        try {
            System.out.println("Starting to process socket");
            //Thread.sleep(10000);//10 seconds
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            String credentials = (String) ois.readObject();//get credentials from client
            boolean isValid = authenticate(credentials);
            oos.writeObject(new Boolean(isValid));//send result to client
            oos.flush();
            socket.close();
            System.out.println("Finishing");
        } catch (Exception e) {
            System.out.println("Auth server Exception: " + e.getMessage());
            //System.out.println("Flushed processing socket");
        }
    }
    
    private boolean authenticate(String credentials) {
        String[] tokens = credentials.split("/");
        if (tokens.length != 2) return false;
        String username = tokens[0];
        String password = tokens[1];
        if (username.equals("hello") && password.equals("world")) {
            return true;
        } else {
            return false;
        }
    }

}
