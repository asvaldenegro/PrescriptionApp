/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package authenticationsvr.business;

import java.net.*;
import java.io.*;

/**
 *
 * @author Amorette
 */
public class SocketListener {
    public void run() {//run listens for incoming connections, reads, authenticates, writes socket and closes
        System.out.println("Starting to listen for socket connections");
        try {
            ServerSocket ss = new ServerSocket(8000, 100);
            while(true){
                Socket socket = ss.accept();//blocks, waiting for a connection request
                SocketMgr socketMgr = new SocketMgr(socket);
                Thread thread = new Thread(socketMgr);
                thread.start();
            }
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
    private boolean authenticate(String credentials) {
        String[] tokens = credentials.split("/");
        if (tokens.length != 2) return false;
        String username = tokens[0];
        String password = tokens[1];
        if (username.equals("hello") && password.equals("world")) {
            return true;
        } else {
            return false;
        }
    }
}
