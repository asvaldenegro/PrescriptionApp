/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.business;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import org.junit.Test;
import prescriptionapp.domain.*;
/**
 *
 * @author Amorette
 */
public class PrescriptionMgrTest {
    @Test
    public void testCRUD() throws Exception {
        Prescription prescription = new Prescription();
        prescription.setPrescriptionName("Hydrocodone");
        prescription.setPrescriptionDosage("40 mg");
        prescription.setPrescriptionUse("Pain");
        PrescriptionMgr mgr = new PrescriptionMgr();
        prescription = mgr.create(prescription);
        assertNotNull(prescription);
        prescription = mgr.retrieve(prescription);
        assertNotNull(prescription);
        prescription = mgr.delete(prescription);
        assertNotNull(prescription);
        prescription = mgr.retrieve(prescription);
        assertNull(prescription);
    }
}
