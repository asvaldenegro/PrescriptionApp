 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.domain;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amorette
 */
public class PrescriptionTest {
    @Test
    public void testValidate(){
        Prescription prescription = new Prescription();
        boolean result = prescription.validate();
        
        assertFalse(result);
        prescription.setPrescriptionName("Advicor");
        result = prescription.validate();
        
        assertFalse(result);
        prescription.setPrescriptionDosage("10 mg");
        result = prescription.validate();
        
        assertFalse(result);
        prescription.setPrescriptionUse("High Cholesterol");
        result = prescription.validate();
        
        assertFalse(result);
        SideEffect sideeffect = new SideEffect();
        sideeffect.setSideEffect("Dizziness");
        sideeffect.setSeverity("Moderate");
        sideeffect.setDuration("2 hours");
        prescription.add(sideeffect);
        result = sideeffect.validate();
        
        assertTrue(result);
        
    }
    
    
    @Test
    public void testEquals(){
        Prescription prescription1 = new Prescription();
        prescription1.setPrescriptionName("Tylenol-Codeine");
        prescription1.setPrescriptionDosage("5 mg");
        prescription1.setPrescriptionUse("Pain");
        
        Prescription prescription2 = new Prescription();
        boolean result = prescription1.equals(prescription2);
        assertFalse(result);
        
        prescription2.setPrescriptionName("Tylenol-Codeine");
        result = prescription1.equals(prescription2);
        assertFalse(result);
        
        prescription2.setPrescriptionDosage("5 mg");
        result = prescription1.equals(prescription2);
        assertFalse(result);
        
        prescription2.setPrescriptionUse("Pain");
        result = prescription1.equals(prescription2);
        
        assertTrue(result);
    }   
}
