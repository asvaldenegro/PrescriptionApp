/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.domain;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Amorette
 */
public class SideEffectTest {
    @Test
    public void testValidate(){
        SideEffect sideeffect = new SideEffect();
        boolean result = sideeffect.validate();
        
        assertFalse(result);
        sideeffect.setSideEffect("Headache");
        result = sideeffect.validate();
        
        assertFalse(result);
        sideeffect.setSeverity("Severe");
        result = sideeffect.validate();
        
        assertFalse(result);
        sideeffect.setDuration("2 hours");
        result = sideeffect.validate();
        
        assertTrue(result);
    }
    @Test
    public void testEquals(){
        SideEffect sideeffect1 = new SideEffect();
        sideeffect1.setSideEffect("Dizziness");
        sideeffect1.setSeverity("Moderate");
        sideeffect1.setDuration("2 hours");
        
        SideEffect sideeffect2 = new SideEffect();
        boolean result = sideeffect1.equals(sideeffect2);
        assertFalse(result);
        
        sideeffect2.setSideEffect("Dizziness");
        result = sideeffect1.equals(sideeffect2);
        assertFalse(result);
        
        sideeffect2.setSeverity("Moderate");
        result = sideeffect1.equals(sideeffect2);
        assertFalse(result);
        
        sideeffect2.setDuration("2 hours");
        result = sideeffect1.equals(sideeffect2);
        
        assertTrue(result);
    }
}
