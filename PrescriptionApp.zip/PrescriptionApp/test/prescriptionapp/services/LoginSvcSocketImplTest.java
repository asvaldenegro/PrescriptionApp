/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.services;

import org.junit.Test;
import static org.junit.Assert.*;
import prescriptionapp.domain.Login;

/**
 *
 * @author Amorette
 */
public class LoginSvcSocketImplTest {
    @Test
    public void testLogin() {
        try {
            LoginSvcSocketImpl limpl = new LoginSvcSocketImpl();
            Login login = new Login();
            login.setUsername("hello");
            login.setPassword("world");
            boolean result = limpl.authenticate(login);
            assertTrue(result);
            login.setUsername("hellloooooo");
            login.setPassword("worlddd");
            result = limpl.authenticate(login);
            assertFalse(result);
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }

}
