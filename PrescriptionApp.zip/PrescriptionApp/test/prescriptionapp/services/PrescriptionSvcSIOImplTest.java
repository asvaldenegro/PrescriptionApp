/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.services;

import org.junit.Test;
import static org.junit.Assert.*;
import prescriptionapp.domain.Prescription;

/**
 *
 * @author Amorette
 */
public class PrescriptionSvcSIOImplTest {
    @Test
    public void testCRUD()throws Exception{
        Prescription prescription = new Prescription();
        prescription.setPrescriptionName("Hydrocodone");
        prescription.setPrescriptionDosage("100 mg");
        prescription.setPrescriptionUse("Pain");
        IPrescriptionSvc svc = new PrescriptionSvcSIOImpl();
        svc.clear();
        prescription = svc.store(prescription);
        assertNotNull(prescription);
        assertEquals(svc.size(), 1);
        prescription = svc.delete(prescription);
        assertNotNull(prescription);
        prescription = svc.retrieve("Hydrocodone");
        assertNull(prescription);
        }
}
