/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.services;

import prescriptionapp.domain.Login;

/**
 *
 * @author Amorette
 */
public interface ILoginSvc extends IService{
    public boolean authenticate(Login login) throws SvcException;
}
