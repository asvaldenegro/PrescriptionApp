/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.services;
import prescriptionapp.domain.*;
import java.io.*;
import java.util.*;
/**
 *
 * @author Amorette
 */
public class PrescriptionSvcSIOImpl implements IPrescriptionSvc{
    private static final String FILENAME = "prescriptions.sio";
    public Prescription store(Prescription prescription)throws SvcException{
        try {
            prescriptions.add(prescription);
            writeFile();
        } catch (Exception e) {
            throw new SvcException(e.getMessage());
        }
        return prescription;
    }
    public Prescription retrieve(String name)throws SvcException{
        try {
            for (int i = 0; i < prescriptions.size(); i++) {
                Prescription prescription = prescriptions.get(i);
                if (prescription.getPrescriptionName().equals(name)) {
                    return prescription;
                }
            }
        }catch(Exception e){
                throw new SvcException(e.getMessage());
        }
        return null;  
        }
    
    private List<Prescription> prescriptions = new ArrayList<Prescription>();
    
    public List<Prescription> retrieveAll() throws SvcException{
        return prescriptions;
    }
    public PrescriptionSvcSIOImpl(){
        readFile();
    }
    
    private void readFile(){
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILENAME));
            prescriptions = (List<Prescription>) ois.readObject();
            ois.close();
        } catch (Exception e) {
            prescriptions = new ArrayList<Prescription>();
        }
    }
    private void writeFile(){
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILENAME));
            oos.writeObject(prescriptions);
            oos.close();
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
    public Prescription update(Prescription prescription) throws SvcException{
        throw new SvcException("not implemented");
        //return prescription;
    }
    public Prescription delete(Prescription prescription) throws SvcException{
        for(int i = 0; i < prescriptions.size(); i++){
            Prescription p = prescriptions.get(i);
            if(p.equals(prescription)){
                prescriptions.remove(i);
                writeFile();
                return prescription;
            }
        }
    return null;
    }
    public int size(){
        return prescriptions.size();
    }
    public void clear(){
        prescriptions.clear();
        writeFile();
    }
}
