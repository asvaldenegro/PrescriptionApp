/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.services;
import java.io.FileInputStream;
import java.util.*;

/**
 *
 * @author Amorette
 */
public class Factory {
    public IPrescriptionSvc getPrescriptionSvc(){
        return new PrescriptionSvcSIOImpl();
    }
    
    public IService getService(String serviceName) throws Exception{
        String implName = getImplName(serviceName);
        Class c = Class.forName(implName);//Dynamically loads the class at @runtime
        return (IService) c.newInstance();
    }
    
    private String getImplName(String serviceName) throws Exception{
        Properties props = new Properties();
        FileInputStream fis = new FileInputStream("Factory.properties");
        props.load(fis);
        fis.close();
        return props.getProperty(serviceName);
    }
    public ILoginSvc getLoginSvc(){
        return new LoginSvcSocketImpl();
    }
}
