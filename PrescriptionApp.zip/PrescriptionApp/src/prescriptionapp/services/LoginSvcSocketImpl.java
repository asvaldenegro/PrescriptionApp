/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.services;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import prescriptionapp.domain.Login;

/**
 *
 * @author Amorette
 */
public class LoginSvcSocketImpl implements ILoginSvc {

    @Override
    public boolean authenticate(Login login) throws SvcException {
        boolean isValid = false;
        try {
            InetAddress address = InetAddress.getLocalHost();
            Socket socket = new Socket(address, 8000);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            String usernamePassword = login.getUsername() + '/' + login.getPassword();
            oos.writeObject(usernamePassword);
            isValid = (Boolean) ois.readObject();
            oos.flush();
            socket.close();
            return isValid;
        } catch (Exception e) {
            System.out.println("Exception: " + e.getMessage());
        }
        return isValid;
    }
}
