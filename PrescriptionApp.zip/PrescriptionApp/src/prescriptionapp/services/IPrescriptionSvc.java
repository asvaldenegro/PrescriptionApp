/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.services;
import java.util.List;
import prescriptionapp.domain.*;
/**
 *
 * @author Amorette
 */
public interface IPrescriptionSvc extends IService{
    public final String NAME = "IPrescriptionSvc";
    public Prescription store(Prescription prescription)throws SvcException;
    public Prescription retrieve(String name) throws SvcException;
    public List<Prescription> retrieveAll() throws SvcException;
    public Prescription update(Prescription prescription) throws SvcException;
    public Prescription delete(Prescription prescription) throws SvcException;
    public int size ();
    public void clear();
}
        
