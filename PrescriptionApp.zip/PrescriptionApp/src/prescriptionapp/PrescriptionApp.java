/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp;
import java.util.Scanner;
import prescriptionapp.domain.Prescription;
/**
 *
 * @author Amorette
 */
public class PrescriptionApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner scanner = new Scanner(System.in);
        Prescription prescription = new Prescription();
        
        System.out.println("Enter prescription name: ");
        String prescriptionName = scanner.nextLine();
        prescription.setPrescriptionName(prescriptionName);
        
        System.out.println("Enter the prescription dosage: ");
        String prescriptionDosage = scanner.nextLine();
        prescription.setPrescriptionDosage(prescriptionDosage);
        
        System.out.println("Enter the use of this prescription: ");
        String prescriptionUse = scanner.nextLine();
        prescription.setPrescriptionUse(prescriptionUse);
        
        System.out.println(prescription);
    }
    
}
