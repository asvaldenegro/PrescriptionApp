/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.business;
import java.util.ArrayList;
import prescriptionapp.domain.*;
import java.util.List;
import prescriptionapp.services.*;
/**
 *
 * @author Amorette
 */
public class PrescriptionMgr extends ManagerAbs{
//    private IPrescriptionSvc prescriptionSvc = null;
//    public PrescriptionMgr(){
//        IPrescriptionSvc prescriptionSvc = factory.getPrescriptionSvc();
//        IPrescriptionSvc svc = (IPrescriptionSvc) factory.getService(IPrescriptionSvc.NAME);
//    }
    public Prescription create(Prescription p) throws SvcException{
        //IPrescriptionSvc svc = (IPrescriptionSvc) factory.getService(IPrescription.NAME);
        IPrescriptionSvc prescriptionSvc = factory.getPrescriptionSvc();
        p = prescriptionSvc.store(p);
        return p;
    }
    
    public List<Prescription> retrieveAll() throws SvcException{
        List<Prescription> prescriptions = null;
        IPrescriptionSvc prescriptionSvc = factory.getPrescriptionSvc();
        prescriptions = prescriptionSvc.retrieveAll();
        return prescriptions;
    }
    
    public Prescription retrieve(Prescription p) throws SvcException{
        IPrescriptionSvc prescriptionSvc = factory.getPrescriptionSvc();
        p = prescriptionSvc.retrieve(p.getPrescriptionName());
        return p;
    }
    
    public Prescription update(Prescription p) throws SvcException{
        IPrescriptionSvc prescriptionSvc = factory.getPrescriptionSvc();
        p = prescriptionSvc.update(p);
        return p;
    }
    public Prescription delete(Prescription p) throws SvcException{
        IPrescriptionSvc prescriptionSvc = factory.getPrescriptionSvc();
        p = prescriptionSvc.delete(p);
        return p;
    }
}
