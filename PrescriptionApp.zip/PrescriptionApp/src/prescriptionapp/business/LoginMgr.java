/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.business;
import prescriptionapp.domain.Login;
import prescriptionapp.services.*;
/**
 *
 * @author Amorette
 */
public class LoginMgr extends ManagerAbs{
    ILoginSvc loginSvc = factory.getLoginSvc();
    public boolean authenticate(Login login) {
        if (login.getUsername().equals("hello") && login.getPassword().equals("world")) return true;
        else {
            return false;
        }
    }
}