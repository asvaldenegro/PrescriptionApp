/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.domain;
import java.util.*;
/**
 *
 * @author Amorette
 */
public class SideEffect extends DomainAbs {
    private String sideEffect = "";
    private String severity = "";
    private String duration = "";
    /**
     * @return the sideEffect
     */
    public boolean validate(){
        if(sideEffect==null || sideEffect.equals(""))return false;
        if(severity==null || severity.equals(""))return false;
        if(duration==null || duration.equals(""))return false;
        return true;
    }
    
    @Override
    public boolean equals(Object obj){
        if(this==obj)return true;
        if(!(obj instanceof SideEffect))return true;
        SideEffect sideeffect = (SideEffect)obj;
        if(!sideEffect.equals(sideeffect.sideEffect))return false;
        if(!severity.equals(sideeffect.severity))return false;
        if(!duration.equals(sideeffect.duration))return false;
        return true;
    }
    
    public String getSideEffect() {
        return sideEffect;
    }

    /**
     * @param sideEffect the sideEffect to set
     */
    public void setSideEffect(String sideEffect) {
        this.sideEffect = sideEffect;
    }

    /**
     * @return the severity
     */
    public String getSeverity() {
        return severity;
    }

    /**
     * @param severity the severity to set
     */
    public void setSeverity(String severity) {
        this.severity = severity;
    }

    /**
     * @return the duration
     */
    public String getDuration() {
        return duration;
    }

    /**
     * @param duration the duration to set
     */
    public void setDuration(String duration) {
        this.duration = duration;
    }
}
