/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.domain;

/**
 *
 * @author Amorette
 */
public class Login extends DomainAbs{
    private String username = "";
    private String password = "";

    public boolean validate(){
        if (username == null || username.equals("")) return false;
        if (password == null || password.equals("")) return false;
        return true;
    }
    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password the password to set
     */
    public void setPassword(String password) {
        this.password = password;
    }
}
