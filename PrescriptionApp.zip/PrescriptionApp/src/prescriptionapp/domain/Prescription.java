/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prescriptionapp.domain;
import java.util.*;
/**
 *
 * @author Amorette
 */
public class Prescription extends DomainAbs {
    private String prescriptionName = "";
    private String prescriptionDosage = "";
    private String prescriptionUse = "";
    /**
     * @return the prescriptionName
     */
    private List <SideEffect> sideEffects = new ArrayList();
    
    public void add(SideEffect sideeffect){
        sideEffects.add(sideeffect);
    }
    
    @Override
    public String toString(){
        return "prescriptionName:"+ prescriptionName +", prescriptionDosage:" + prescriptionDosage + ", prescriptionUse:" + prescriptionUse;
    }
    
    public boolean validatePresentation() {
        if(!super.validate())return false;
        if (prescriptionName==null || prescriptionName.equals("")) return false;
        if (prescriptionDosage==null || prescriptionDosage.equals("")) return false;
        return !(prescriptionUse==null || prescriptionUse.equals(""));
    }
    
    @Override
    public boolean validate(){
        if(!super.validate())return false;
        if (prescriptionName==null || prescriptionName.equals("")) return false;
        if (prescriptionDosage==null || prescriptionDosage.equals("")) return false;
        if (prescriptionUse==null || prescriptionUse.equals("")) return false;
        if (sideEffects==null || sideEffects.size()==0)return false;
        return true;
    }
    
    @Override
    public boolean equals(Object obj){
        if(!super.equals(obj))return false;
        if(!(obj instanceof Prescription)) return true;
        Prescription prescription = (Prescription) obj;
        if(!prescriptionName.equals(prescription.prescriptionName))return false;
        if(!prescriptionDosage.equals(prescription.prescriptionDosage))return false;
        if(!prescriptionUse.equals(prescription.prescriptionUse))return false;
        //if(sideEffects.size()!=prescription.sideEffects.size())return false;
        //for(int i=0;i<sideEffects.size();i++){
        //    if(!sideEffects.get(i).equals(prescription.sideEffects.get(i)))return false;
        //}
        return true;
    }
    
    public String getPrescriptionName() {
        return prescriptionName;
    }

    /**
     * @param prescriptionName the prescriptionName to set
     */
    public void setPrescriptionName(String prescriptionName) {
        this.prescriptionName = prescriptionName;
    }

    /**
     * @return the prescriptionDosage
     */
    public String getPrescriptionDosage() {
        return prescriptionDosage;
    }

    /**
     * @param prescriptionDosage the prescriptionDosage to set
     */
    public void setPrescriptionDosage(String prescriptionDosage) {
        this.prescriptionDosage = prescriptionDosage;
    }

    /**
     * @return the prescriptionUse
     */
    public String getPrescriptionUse() {
        return prescriptionUse;
    }

    /**
     * @param prescriptionUse the prescriptionUse to set
     */
    public void setPrescriptionUse(String prescriptionUse) {
        this.prescriptionUse = prescriptionUse;
    }
    
}
